Before running the command to launch the docker containers created by composer (given below), ensure that:

1. You have located the data/db folder
2. Allowed Docker Desktop (or the VM) shared access of the folder location
3. Amended line 23 to reflect the appropriate path for your system

Launch the containers on the command line using the command docker-compose up
Safely dispose of the containers by pressing CTRL+C and then the command docker-compose down
