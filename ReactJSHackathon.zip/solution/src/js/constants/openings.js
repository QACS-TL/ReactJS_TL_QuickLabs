export const openingTimes = [{
    "_id": "5ca730905f52db3c8f637a34",
    "day": "Monday",
    "opening": "11:00",
    "close": "00:00"
}, {
    "_id": "5ca730905f52db3c8f637a35",
    "day": "Friday",
    "opening": "11:00",
    "close": "02:00"
}, {
    "_id": "5ca730905f52db3c8f637a36",
    "day": "Sunday",
    "opening": "11:00",
    "close": "23:00"
}];