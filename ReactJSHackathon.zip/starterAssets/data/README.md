To start JSON-SERVER to mimic how the real backend service run the following command:

json-server --watch -p 80 cinemamockdata.json --id \_id

If there are issues working on Port 80, use sudo in front of the command on MacOS
For Windows, make sure that the Command Prompt is running as administrator
