import React from 'react';

const Home = () => {
    return (
        <p>Home content here</p>
    );
}

export default Home;