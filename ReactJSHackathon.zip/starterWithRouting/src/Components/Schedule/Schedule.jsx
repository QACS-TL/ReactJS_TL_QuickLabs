import React from 'react';

const Schedule = () => {
    return (
        <p>Schedule content here</p>
    );
}

export default Schedule;