export const HOMEIMAGES = [
    { src: `images/popcorn.jpeg`, alt: `QA Cinemas` },
    { src: `images/InternationalHouse.jpeg`, alt: `QA London` },
    { src: `images/download.jpeg`, alt: `QA Manchester` }
];