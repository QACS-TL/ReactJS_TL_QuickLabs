import React from 'react';

const MyComponent = () => {
    return (
        <h1>Hello World</h1>
    );
};

export default MyComponent;
